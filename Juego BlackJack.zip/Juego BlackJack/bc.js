document.addEventListener('DOMContentLoaded', () => {
    let deck = [];
    let playerCards = [];
    let dealerCards = [];
    let playerPoints = 0;
    let dealerPoints = 0;

    
    function createDeck() {
        const suits = {
            'H': '♥',
            'D': '♦',
            'C': '♣',
            'S': '♠'
        };
        const values = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
        deck = [];

        for (let suit in suits) {
            for (let value of values) {
                deck.push(`${value}${suits[suit]}`);
            }
        }

        deck = _.shuffle(deck);
    }

    function drawCard() {
        return deck.pop();
    }

    function getCardValue(card) {
        const value = card.slice(0, -1);
        if (['J', 'Q', 'K'].includes(value)) return 10;
        if (value === 'A') return 11;
        return parseInt(value);
    }

    function updatePoints() {
        playerPoints = playerCards.reduce((sum, card) => sum + getCardValue(card), 0);
        dealerPoints = dealerCards.reduce((sum, card) => sum + getCardValue(card), 0);
        document.getElementById('playerPoints').textContent = playerPoints;
        document.getElementById('dealerPoints').textContent = dealerPoints;
    }

    function renderCards() {
        const playerZone = document.getElementById('player-cards');
        const dealerZone = document.getElementById('dealer-cards');
        playerZone.innerHTML = '';
        dealerZone.innerHTML = '';

        playerCards.forEach(card => {
            const div = document.createElement('div');
            div.className = 'card';
            div.textContent = card;
            div.style.color = card.includes('♥') || card.includes('♦') ? 'red' : 'black';
            playerZone.appendChild(div);
        });

        dealerCards.forEach(card => {
            const div = document.createElement('div');
            div.className = 'card';
            div.textContent = card;
            div.style.color = card.includes('♥') || card.includes('♦') ? 'red' : 'black';
            dealerZone.appendChild(div);
        });
    }

    function startGame() {
        createDeck();
        playerCards = [drawCard(), drawCard()];
        dealerCards = [drawCard(), drawCard()];
        updatePoints();
        renderCards();
        document.getElementById('datos').value = '';
        document.getElementById('hitBtn').disabled = false;
    }

    function pedirCarta() {

        playerCards.push(drawCard());
        updatePoints();
        renderCards();
        if (playerPoints > 21) {
            document.getElementById('datos').value = "Te has pasado. Pierdes.";
            document.getElementById('hitBtn').disabled = true;
        }
    }

    function plantarse() {
        while (dealerPoints < 17) {
            dealerCards.push(drawCard());
            updatePoints();
            renderCards();
        }

        const datos = document.getElementById('datos');
        if (playerPoints > 21) {
            datos.value = "Te has pasado. Pierdes.";
        } else if (dealerPoints > 21 || playerPoints > dealerPoints) {
            datos.value = "¡Has ganado!";
        } else if (playerPoints === dealerPoints) {
            datos.value = "Empate.";
        } else {
            datos.value = "Pierdes.";
        }
    }

    document.getElementById('newGameBtn').addEventListener('click', startGame);
    document.getElementById('hitBtn').addEventListener('click', pedirCarta);
    document.getElementById('standBtn').addEventListener('click', plantarse);
});
